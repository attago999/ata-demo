package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
)

var (
	ErrPrivateKeyFailedToLoad = errors.New("crypto4go: private key failed to load")
	ErrPublicKeyFailedToLoad  = errors.New("crypto4go: public key failed to load")
)

func packageData(originalData []byte, packageSize int) (r [][]byte) {
	var src = make([]byte, len(originalData))
	copy(src, originalData)

	r = make([][]byte, 0)
	if len(src) <= packageSize {
		return append(r, src)
	}
	for len(src) > 0 {
		var p = src[:packageSize]
		r = append(r, p)
		src = src[packageSize:]
		if len(src) <= packageSize {
			r = append(r, src)
			break
		}
	}
	return r
}

// Encrypt
func rsaEncrypt(plaintext []byte, pubKey []byte) ([]byte, error) {
	pubInterface, err := x509.ParsePKIXPublicKey(pubKey)
	if err != nil {
		return nil, err
	}
	pub, ok := pubInterface.(*rsa.PublicKey)
	if !ok {
		return nil, ErrPublicKeyFailedToLoad
	}
	cipherText, err := rsaEncryptWithKey(plaintext, pub)
	if err != nil {
		return nil, err
	}
	return cipherText, nil

}
func rsaEncryptWithKey(src []byte, key *rsa.PublicKey) ([]byte, error) {
	var data = packageData(src, key.N.BitLen()/8-11)
	var cipher = make([]byte, 0)

	for _, d := range data {
		var c, e = rsa.EncryptPKCS1v15(rand.Reader, key, d)
		if e != nil {
			return nil, e
		}
		cipher = append(cipher, c...)
	}

	return cipher, nil
}

// Decrypt
func rsaDecrypt(cipherText []byte, priKey []byte) ([]byte, error) {
	priInterface, err := x509.ParsePKCS8PrivateKey(priKey)
	if err != nil {
		return nil, err
	}
	pri, ok := priInterface.(*rsa.PrivateKey)
	if !ok {
		return nil, ErrPrivateKeyFailedToLoad
	}
	plaintext, err := rsaDecryptWithKey(cipherText, pri)
	if err != nil {
		return nil, err
	}
	return plaintext, nil
}
func rsaDecryptWithKey(cipher []byte, key *rsa.PrivateKey) ([]byte, error) {
	var data = packageData(cipher, key.PublicKey.N.BitLen()/8)
	var plainData = make([]byte, 0)

	for _, d := range data {
		var p, e = rsa.DecryptPKCS1v15(rand.Reader, key, d)
		if e != nil {
			return nil, e
		}
		plainData = append(plainData, p...)
	}
	return plainData, nil
}

// Sign
func rsaPKCS8Sign(src []byte, privateKey []byte, hash crypto.Hash) ([]byte, error) {
	priInterface, err := x509.ParsePKCS8PrivateKey(privateKey)
	if err != nil {
		return nil, err
	}
	pri, ok := priInterface.(*rsa.PrivateKey)
	if !ok {
		return nil, ErrPrivateKeyFailedToLoad
	}
	if hash <= 0 {
		hash = crypto.SHA256
	}
	sign, err := rsaSignWithKey(src, pri, hash)
	if err != nil {
		return nil, err
	}
	return sign, nil
}
func rsaSignWithKey(src []byte, privateKey *rsa.PrivateKey, hash crypto.Hash) ([]byte, error) {
	var h = hash.New()
	h.Write(src)
	var hashed = h.Sum(nil)
	return rsa.SignPKCS1v15(rand.Reader, privateKey, hash, hashed)
}

// Verify
func rsaPKCS8Verify(src, sign []byte, publicKey []byte, hash crypto.Hash) (bool, error) {
	pubInterface, err := x509.ParsePKIXPublicKey(publicKey)
	if err != nil {
		return false, err
	}
	pub, ok := pubInterface.(*rsa.PublicKey)
	if !ok {
		return false, ErrPublicKeyFailedToLoad
	}
	if hash <= 0 {
		hash = crypto.SHA256
	}
	err = rsaVerifyWithKey(src, sign, pub, hash)
	if err != nil {
		return false, err
	}
	return true, err
}
func rsaVerifyWithKey(src, sign []byte, key *rsa.PublicKey, hash crypto.Hash) error {
	var h = hash.New()
	h.Write(src)
	var hashed = h.Sum(nil)
	return rsa.VerifyPKCS1v15(key, hash, hashed, sign)
}

// encrypt and sign
func encryptAndSign(plaintesxt []byte, publicKey, privateKey string) (context, sign string, err error) {
	pub, _ := base64.StdEncoding.DecodeString(publicKey)
	pri, _ := base64.StdEncoding.DecodeString(privateKey)
	var ciphertext, signData []byte

	if ciphertext, err = rsaEncrypt(plaintesxt, pub); err != nil {
		fmt.Printf("encryp error: %s\n", err.Error())
		return
	}
	context = base64.StdEncoding.EncodeToString(ciphertext)
	if signData, err = rsaPKCS8Sign(ciphertext, pri, crypto.SHA256); err != nil {
		fmt.Printf("sign error: %s\n", err.Error())
		return
	}
	sign = base64.StdEncoding.EncodeToString(signData)
	return
}

// decrypt and verify
func decryptAndVery(context, sign, publicKey, privateKey string) (data []byte, err error) {
	con, _ := base64.StdEncoding.DecodeString(context)
	sig, _ := base64.StdEncoding.DecodeString(sign)
	pri, _ := base64.StdEncoding.DecodeString(privateKey)
	pub, _ := base64.StdEncoding.DecodeString(publicKey)

	if data, err = rsaDecrypt(con, pri); err != nil {
		fmt.Printf("decryp error: %s\n", err.Error())
		return
	}
	if _, err = rsaPKCS8Verify(con, sig, pub, crypto.SHA256); err != nil {
		fmt.Printf("verify error: %s\n", err.Error())
		return
	}
	return
}

func main() {
	platPublicKey := "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwQSj/SnqKo9SE7LadfOK9CVitORiWf5c/ZM5Kzi/WhixymxPAQgBw7IwGaitE510TOEVTV4N9gzKl68bPkHUViS2EB6peoAL3cLY80Hm6FG9cxBO2o278PSHuzo01aZvLlEfcBVNQjo+03D0LvLLcS6wicqwqCmJffYAwPG6sPzu4MCy7pP4NvvOpqxfr2O2JKGKe1C2t5IztnvNjgvJuKDmX8x2i9Uzxt69ZZzewiTnih6Z8YdcNPwpS5PCozPoZy3U4fXsd6bPDBrHDYT2U9P6VnRi4LBxBKXKC8O5j5LQCEHqBWsaa+yffVePdiBOHAVFFvbQtQXIAwX3WmglsQIDAQAB"
	mchtPrivateKey := "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCv9WEeE5dfIMH9PzpfTILqIp4F2x300mPaFjJWMiMvl1F8EgtId/qaAbhAw6Ycqyq2ti/TpVYT4tceyjRb4BIUaUYg7bhS97Vd0DIWe3QTk8tM4x5YiFmgkcCC177oD1FruLT++mjYLZdNby+z3rwI7pjDsbwA+HwxtA26SZcMYPAua0wguzylbH+1/Xc8rWGDS8KfF9FILiWdk/9nrbT1Wt9wulUU0g70qLsFbIPIwJwBsQ6pptCHaqQjdCn3EH4i6kGL5K/6dHgFgqdkQsrqZgt/pBtgxQgjzKEM9eF+d+1O6eYXevPzgWoCXl9NDZuwIngkGu830/+MPTtN9K4jAgMBAAECggEAXxcTkeZygnU4gLyftgqqIQ/uKCn/KWRdk+k08MINo9V5srwpntM/+eR+B3n0FkAmSDFy7UTHnN2U9c2+t/wCqUcvH/J4D1ZQjE9MEjxLQZ04W+fNaXjePtklmVAwmkZU8QsTvUvkRxd0UeOJewIeyhDvO6qceEXRECdG1+qXF5eR5LIt8o5T0F9hoyTw7y2v6WrigYSMZCGrbVBhonKHsUeRwQxNL/xwscxjTR2vyJmIjl7CcXuGPz7/ty/yQDq09GAj6E5trLFvSzxoLEHAOpaH0ELrOUsqaELoprwdKDKTleDIdu8ACuYjOyWNpt7phjBWCuomwOYODkFPCdP8iQKBgQDfODhGqYRNmZBClS7R9uTdGxMmPT68NPKfFmbF/jcPASnc0ULG2Vl5IKNjZT9IPzm9PHbPjVpWPYeoXExWCryZNByROfmUL4ci76KXC+2V2PbZS+hCGCxgndKKQKFmEtHrDBJkZw4/DW3ry540kyuuIiIdKVBxAZG1DPB2T889vwKBgQDJzGmpYXhjrqT6uBw5liQ8Gl42XGefWFVXKXcApoEQIxQkBRKtdpBh+LttI+rXsx9l2eIi8qZ4Z1qnQBtgtHRL+/VCy6rOksNwIN8XoitLfMgXqWkIOp8W8UUAnhQjQ3Y3vwpvDL1LLE3ASNRxgFIQGO2Ch8ZlpJ63yPAUobgwnQKBgBd16TREDMu7IBZfZ5RZxqQWfGTAex980SM3T4XvugmxrZyvwbz0ixrX+1QvB/+n5YGmITafPKdjwCZJzRwd9MSFXZtF5J1WgXWCiiwl7MqbCxa7i6WmtMNS0xYExPHdeIKjuisjSbQGzU7DD9WmwiiDHeLCvNmjuJS2z28f5EAxAoGBAK8XzhZJnEvhnQRt+w98VrRPrK8+PirkWifmsnq9/f4icbdPL4WS+nQHfZiVMY82vGeDRdNM92RBSUcVOKwP51iGpafvT6UtcqY331qCO06kVnkxZRDezGr7rQN8JbzzK//yovr38sbnCg9tIefZj1qoRmybomlPDOgqUSWVrFuBAoGBAM7qXh+D0G0DkoOnDJFK6QgMGF9zDoyMZyWHUgC2ORqTg55bfclcer/Qdwt0ORjtLFclU3bhIBuNvR5UJUlom+u140sDSVEjyDcy5zS3PGb0ikt1eU/yioAu924NMc/yr+3Pyj1NwW2QC7plVBI0EzTE6H3HSjLpsa1lpQgbu7X8"

	/****** place order ******/
	type orderInfo struct {
		MchtOrderNo      string `json:"mcht_order_no"`      // merchant order number
		MchtNo           string `json:"mcht_no"`            // merchant number
		ChannelNo        int    `json:"channel_no"`         // channel number
		Amount           string `json:"amount"`             // order amount
		ReturnSuccessUrl string `json:"return_success_url"` // success url(order success redirect url)
		ReturnFailureUrl string `json:"return_failure_url"` // failure url(order failure redirect url)
		NotifyUrl        string `json:"notify_url"`         // notify url(order success callback url)
		ReqTime          string `json:"req_time"`           // request timestamp(length 13)
		Code             string `json:"code"`               // code
		Type             string `json:"type"`               // type
		Name             string `json:"name"`               // name
		Phone            string `json:"phone"`              // phone
		Email            string `json:"email"`              // email
		Account          string `json:"account"`            // account
		Address          string `json:"address"`            // address
		Ifsc             string `json:"ifsc"`               // ifsc
		Cnic             string `json:"cnic"`               // cnic
		Cert             string `json:"cert"`               // cert
		Extend           string `json:"extend"`             // extend
	}
	order := orderInfo{}
	order.MchtOrderNo = "36711319579415750099154"
	order.MchtNo = "test"
	order.ChannelNo = 901001
	order.Amount = "123.45"
	order.ReturnSuccessUrl = "http://www.google.com"
	order.ReturnFailureUrl = "http://www.google.com"
	order.NotifyUrl = "http://www.google.com"
	order.ReqTime = "2000000000000"
	order.Code = "QRIS"
	order.Type = "qris"
	order.Name = "test"
	order.Phone = "72838378312"
	order.Email = "dheugg@gmail.com"

	encryptData, err := json.Marshal(&order)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("Plaintext data:%s\n", string(encryptData))

	var context, sign string
	context, sign, err = encryptAndSign(encryptData, platPublicKey, mchtPrivateKey)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("Enciphered data:{\"context\":\"%s\",\"sign\":\"%s\"}\n", context, sign)

	/****** callback order ******/
	context = `bx++F3PzgnXKKF9d8kRs4uYAD0R2Gm/Kpf6bUOQZbmejh48jtVjqe9hFTUpnr1dnZ5x6sMFOsK51OomL+SGhHimsASXc+eIixilSe4MYpga+0xddgKnHHhD3v+oragodx/P12Mk711fINz1vAZKjE0ar5aInmJq1OedakQpiZMmRTzUA7wHdbxzMAkaiRu9j0XcXO+UozsDiMwV3b9Xih9UZfd3qO5BoxsQcXKyA8Tq/Sfj8GYfxick9Znsw/YdDx5uSApN4o+FLqsS4b+K9Wj4WgjUHNFIiZxlJrm4LXBX34xjb7bfvJztQKzf/jYnmDnApsarZHvXLOJBXU6VrMg==`
	sign = `vQXwIwdFjSFXNR/rXf+QbeqHOdSoHYHhonQmJrJAIDLXywwucsnDEg2x0jaemfKjCDY/kdSWbwQelhJszrnTYf5yHdniz9/WEHLGl7S++s1muE6Qeuz6WZo77poUEEHdqfn4D0s2trWRNMOpIAMlGOxEf2fBK9lfY9XLOjmwHAebKkg/jXWfOw4+7XKT7c4blGA4X2YBZkqFi1W0CnwHZd/kxCA+gUa65yA3DgIj3FYm43xqIUkPPQJohWxdxnFpuAu1AYOrONX8NRNPaJ+Lo0grZkLvWv0LQ7uRQ+WyiWyIRSQsPsEBHME8rmTOQKFv2tgFi6FYi06TveWSHHiQ8w==`
	var decryptData []byte
	decryptData, err = decryptAndVery(context, sign, platPublicKey, mchtPrivateKey)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Printf("Decrypt data:%s\n", string(decryptData))
}
