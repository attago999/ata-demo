const crypto = require("crypto");

function loadPublicKey(pemData) {
  return crypto.createPublicKey(pemData);
}

function loadPrivateKey(pemData) {
  return crypto.createPrivateKey(pemData);
}

function publicKeyEncrypt(data, publicKeyPem) {
  const publicKey = loadPublicKey(publicKeyPem);
  const blockSize = 245;
  let encryptedData = [];

  for (let i = 0; i < data.length; i += blockSize) {
    const chunk = data.slice(i, i + blockSize);
    const encryptedChunk = crypto.publicEncrypt(
      {
        key: publicKey,
        padding: crypto.constants.RSA_PKCS1_PADDING,
      },
      Buffer.from(chunk)
    );
    encryptedData.push(encryptedChunk);
  }

  return Buffer.concat(encryptedData).toString("base64");
}

function privateKeyDecrypt(data, privateKeyPem) {
  const privateKey = loadPrivateKey(privateKeyPem);
  const blockSize = 256;
  const encryptedData = Buffer.from(data, "base64");
  let decryptedData = [];

  for (let i = 0; i < encryptedData.length; i += blockSize) {
    const chunk = encryptedData.slice(i, i + blockSize);
    const decryptedChunk = crypto.privateDecrypt(
      {
        key: privateKey,
        padding: crypto.constants.RSA_PKCS1_PADDING,
      },
      chunk
    );
    decryptedData.push(decryptedChunk);
  }

  return Buffer.concat(decryptedData).toString();
}

function privateKeySign(data, privateKeyPem) {
  const privateKey = loadPrivateKey(privateKeyPem);
  const sign = crypto.createSign("SHA256");
  sign.update(Buffer.from(data, "base64"));
  sign.end();
  const signature = sign.sign(privateKey);
  return signature.toString("base64");
}

function publicKeyVerify(data, signature, publicKeyPem) {
  const publicKey = loadPublicKey(publicKeyPem);
  const verify = crypto.createVerify("SHA256");
  verify.update(Buffer.from(data, "base64"));
  verify.end();
  return verify.verify(publicKey, Buffer.from(signature, "base64"));
}

function formatKey(keyStr, keyType = "public") {
  const keyHeader = `-----BEGIN ${keyType.toUpperCase()} KEY-----`;
  const keyFooter = `-----END ${keyType.toUpperCase()} KEY-----`;

  if (keyStr.startsWith(keyHeader) && keyStr.endsWith(keyFooter)) {
    return keyStr;
  }

  const formattedKey = [keyHeader];
  for (let i = 0; i < keyStr.length; i += 64) {
    formattedKey.push(keyStr.slice(i, i + 64));
  }
  formattedKey.push(keyFooter);

  return formattedKey.join("\n");
}

function generateTimestamp() {
  return Date.now().toString();
}

(async () => {
  // Note that the key is only used for testing
  const PLATFORM_PUBLIC_KEY =
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5r3MP/HV4aPh9vlsweB9w5ealEjPH35JtdbizypH1AK0fkm4zKqjSXzz2pJdxUJ7lOIvOLP8Ff0f4dOYtn+4PWRGLUSnG4YYvVI30NsGLDjC6iuaXpUMQ0hlctG/cY1RHfx7DzB5burwwqgxRg6L+pRM/xyVvUAy13SOjKLO4LZj3yExtYXzvX5b3aRtTgCeBTMFRE590Z7T3yVAkyAiS1DLvf1rtn+HbScV+Fu+l+XdbmoUB0XoRy5lnsPa5UxGs1cd3fjTp9V6vUwQVbWvSpnPO95Wa9NgeC+BtJTeFUgX6kFG981UTOX/DkaQcHzIBjYY8QV5Ka8FAl8Yh6fagwIDAQAB";
  // Note that the key is only used for testing
  const MERCHANT_PRIVATE_KEY =
    "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDhDW7ZXm93bKeviJllOJFSq6ksCYA8l7Vw+4TCog11hRcb5JoSjQ2p4xh4nbj7u90yMdtkdM+uxTQ/6T79BAZeQEtTdNHFFLMuoENhc0VlQ6Plb/rcAFJ4O72s6oxtMDrzWWwnJpePkkySOzNLhsJpFYYehy2cr8Hq+Kx7ojYQbjlO8wdrCxkKsVn67Ad5Hf+1LHukBLdQZLQYH0jOEuyjU7lnJ8Stsblyyvjj/WpYBgLnEcKkzB31x05WiqE08nLeP8TydPYLK8NxUAzafvLWMNYgL7tqDp6FacbU/UoMzllLOFij7tEuJp1fCUq28VtpMP5hWv5SBoAVs/3pzKi5AgMBAAECggEAc3pNEsReNc1PDcbtzv6DswPaPnpxjqXZuCuXJ7e3aEHuZaWbWUF/bVjVya5EqQbwrTzf8l/t4SPXd6PbakCSc/JRtHUQ3iuM9bPOX0aiqR9YDfazpgeUSZV98ig3/h7tYMjVshEfW9AZ8j7mRy7SutEMjMWYJfoZatRGzPmi/DJcZbe8nhHLdz6I0B/zmAbaERv2WTiz8Tb4NdHNmjmdPNfMGLKXgOLInyDrH3aCxgHhuPPYIMnKvAOkkA+OVt2azSIcxlOxHQXPLm22snlI74mXiyYpo4z1hKJMmRvKOj6RmbFt5Kp2UMFPi2E59d4Xd0g+tBLrXBobZAxxn7IR8QKBgQDyxMypFjha56YC/aqQMhGfHFQALJJvJbzTJn2eDs1p5nVkoYI6CTZkxeS3vOQnYwzPBPrUHXA0zJqFLEtMyEqtVkQUzCIHeYewBhwAjVtAJ6G2tAF2hV5WdW04HfstqrTYC+oZNCWFH4PiymrdJ8zavBrHWd9o29MuTjcvDH8EKwKBgQDtUXMOaiafftaZOuHiCcsLXZKppsYyC3O0ocYukYpVaIMITmlHIxQusExWxRhz6vsIIlv8aNUraHbOrctDceSw5SfbkbhtwauI5W0S6GC51OCduhdlAYF4b8lE2IBN2ayFyE+uoIkNuvWssJEcWo27AmmDZb8BmZqFaEyu3A6gqwKBgFyABecrUz+34fZjxvh4S2SPu6XxVb5J57+ge96cj0IZkINOUrtgRTxydqpXq6siP4AlypjFurozd3DkprBT5LhVFU3DVff5I207drHzKmCweRqPTbtmJ8LTrVDjg5Ar6gojyAfgaadmka75J2yqvJBfeeiZYtmmYLnVDYu8vCzPAoGBAJFzNShliOyCSba6bw0h4W9C14vhKmIrwKu55wRNsVItbvndTQsLhegjp3Ya8KTDJT5UCLrH6bbkHMUJoaXhnT+KA4bAZh/m7mJF8zb+c6IRxeUF1CbU6GxPXzUx2Fleiy2nmqa1v6pJpx9DTHzrRyiSDuc4qfuqEBmp1i3ps5FnAoGAYII/2Y7zDoRCI8Ogzg4/yoRESoyzGb7mu/lxDj2JnaJkg+mFgDJZ3Yq3+OLwcEbeDEGUuGfnP+VS3FjTPO35AoXu42Z6ATHeinwOtul7HVgwf0hZQmglOrzHOBtHeSaR2wcs3syk3Kt7YnfPRtmOx2G1+NHismUYaki8oxBhWYQ=";

  // the request data
  const jsonDataDict = {
    mcht_order_no: generateTimestamp(),
    mcht_no: "test",
    channel_no: 901001,
    amount: "12300.5",
    notify_url: "http://www.google.com",
    req_time: generateTimestamp(),
    code: "QRIS",
    type: "qris",
    name: "ata",
    phone: "08123456789",
    email: "ata@gmail.com",
  };
  const jsonData = JSON.stringify(jsonDataDict);
  console.log("Original data:", jsonData);

  const ppKey = formatKey(PLATFORM_PUBLIC_KEY, "public");
  const mpKey = formatKey(MERCHANT_PRIVATE_KEY, "private");
  console.log(mpKey);

  let context = publicKeyEncrypt(jsonData, ppKey);
  let sign = privateKeySign(context, mpKey);

  console.log("Encrypted data:", context);
  console.log("Signature:", sign);

  const requestDataDict = {
    context: context,
    sign: sign,
  };
  const requestData = JSON.stringify(requestDataDict);
  console.log("Request data:", requestData);

  // Simulate request and return signature verification and decryption
  context = "n21qr8aMJfe4Pn78525mk/29vGyEkxLA9TbCGvOvVm0nmU5B8HzDmlQ/Zskc3IYk70oYt1+ALU7w7mAdlggGn3wqxfoRhy0HJaeCu3Q6dRYS4YMAhfoQL3BSkD2P8PUhKvuUvh6FfvBMoLx7FF0l4ceOFM1qp8MzglufmynxZ1R3JEJc/37vI4l2Jo7kjLJOgQ0VhrV6Ryu9TdqiFLOEkcj3cTUjVsOPghF7H5qDYe8ruyJ5nLhNWBdkI0+PTja4Uws6EyblnRhNiZNLoVbG+C44CxJuisLfaCSMef6uiLl4elECmwzWCpl/reYeg8vJ0KKGJJl8TOqDuw/uoGXly3HTidtpPFxcweppj6BtKeqYwIPlnAfetYIViPSKN7wQW3r40ogxsrF6c61GZmeAaZEb8+BIhmHK5iUg1diYvzFAhp3+M2EShDDI0gET7jzSalpwZH3sPrcG98aycjEljAILpuEJ91PjdURdzqFFNdWDKjjKbty3dQ5EJkP/uzTLjmZsxJaJAD/K8HpL6fKlSh+xHniXMJrdCI5Qg4upilvOjwaE+mdaJ0+jBgt35nLXwaIggCoa4YKHsYlh5+1xmPz1JpdCGh5Q0SRx3vk+K8gstlnT+6Q/vM8qLKjomALtTQoA/79vVmtyeZgxYx9I1nFaF/ya5pcQ1+aCalTwTh8="
  sign = "tBfvpSLEJpomhdLUJzLy2JxbbsvekiD+QLTYkTG8Oo3UJiayc33M6my5On8SMsYYr62F13dQ6nslpXSAPiWtwHgwVzlcBRFuvFuHqA/KIDZs2ZV51wqwf6MlXzfKXrpJC6WZXy+gEh96mzGglHmbNrd+Eo21ybIzLPz7igX0P2ASNgFKQEKLMVmnpQfNSKM4EgkEFcxK+fE8v3fdiixn4bsQvEG3xPcdU1uXMyauRDAFRCrAFSl7kZMUd7zT78HM6z+NcXwz18znrJuaeQILebGk/3M3TGof1LPBNeO2M9O1cz65y4Cpu8kP07X6KhXGZzw7JzgNGFfWdMJLO20f3g=="
 
  const is_verified = publicKeyVerify(context, sign, ppKey);
  console.log("Verification result:", is_verified);

  const decryptedData = privateKeyDecrypt(context, mpKey);
  console.log("Decrypted data:", decryptedData);
})();
