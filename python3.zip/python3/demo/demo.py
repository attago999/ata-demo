import json
from base64 import b64encode, b64decode
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

def load_public_key(pem_data):
    return serialization.load_pem_public_key(pem_data.encode(), default_backend())

def load_private_key(pem_data):
    return serialization.load_pem_private_key(pem_data.encode(), password=None, backend=default_backend())

# 使用 RSA 公钥加密数据
def public_key_encrypt(data, public_key_pem):
    public_key = load_public_key(public_key_pem)
    block_size = 245
    encrypted_data = []

    for i in range(0, len(data), block_size):
        chunk = data[i:i + block_size]
        encrypted_chunk = public_key.encrypt(
            chunk.encode(),
            padding.PKCS1v15()
        )
        encrypted_data.append(encrypted_chunk)

    return b64encode(b"".join(encrypted_data)).decode()

# 使用 RSA 私钥解密数据
def private_key_decrypt(data, private_key_pem):
    private_key = load_private_key(private_key_pem)
    block_size = 256
    encrypted_data = b64decode(data)
    decrypted_data = []

    for i in range(0, len(encrypted_data), block_size):
        chunk = encrypted_data[i:i + block_size]
        decrypted_chunk = private_key.decrypt(
            chunk,
            padding.PKCS1v15()
        )
        decrypted_data.append(decrypted_chunk)

    return b"".join(decrypted_data).decode()

# 使用 RSA 私钥签名数据
def private_key_sign(data, private_key_pem):
    private_key = load_private_key(private_key_pem)
    signature = private_key.sign(
        b64decode(data),
        padding.PKCS1v15(),
        hashes.SHA256()
    )
    return b64encode(signature).decode()

# 使用 RSA 公钥验证签名
def public_key_verify(data, signature, public_key_pem):
    public_key = load_public_key(public_key_pem)
    try:
        public_key.verify(
            b64decode(signature),
            b64decode(data),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return True
    except Exception:
        return False

# 单行字符串转换为标准的 RSA 公钥或私钥格式（PEM 格式）
# key_type 是密钥的类型（默认为 "public"，也可以是 "private"）
def format_key(key_str: str, key_type: str = "public") -> str:
    key_header = f"-----BEGIN {key_type.upper()} KEY-----"
    key_footer = f"-----END {key_type.upper()} KEY-----"

    if key_str.startswith(key_header) and key_str.endswith(key_footer):
        return key_str
    
    formatted_key = [key_header]
    for i in range(0, len(key_str), 64):
        formatted_key.append(key_str[i:i + 64])
    formatted_key.append(key_footer)

    return "\n".join(formatted_key)


if __name__ == "__main__":
    # Note that the key is only used for testing
    PLATFORM_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5r3MP/HV4aPh9vlsweB9w5ealEjPH35JtdbizypH1AK0fkm4zKqjSXzz2pJdxUJ7lOIvOLP8Ff0f4dOYtn+4PWRGLUSnG4YYvVI30NsGLDjC6iuaXpUMQ0hlctG/cY1RHfx7DzB5burwwqgxRg6L+pRM/xyVvUAy13SOjKLO4LZj3yExtYXzvX5b3aRtTgCeBTMFRE590Z7T3yVAkyAiS1DLvf1rtn+HbScV+Fu+l+XdbmoUB0XoRy5lnsPa5UxGs1cd3fjTp9V6vUwQVbWvSpnPO95Wa9NgeC+BtJTeFUgX6kFG981UTOX/DkaQcHzIBjYY8QV5Ka8FAl8Yh6fagwIDAQAB"
    # Note that the key is only used for testing
    MERCHANT_PRIVATE_KEY = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDhDW7ZXm93bKeviJllOJFSq6ksCYA8l7Vw+4TCog11hRcb5JoSjQ2p4xh4nbj7u90yMdtkdM+uxTQ/6T79BAZeQEtTdNHFFLMuoENhc0VlQ6Plb/rcAFJ4O72s6oxtMDrzWWwnJpePkkySOzNLhsJpFYYehy2cr8Hq+Kx7ojYQbjlO8wdrCxkKsVn67Ad5Hf+1LHukBLdQZLQYH0jOEuyjU7lnJ8Stsblyyvjj/WpYBgLnEcKkzB31x05WiqE08nLeP8TydPYLK8NxUAzafvLWMNYgL7tqDp6FacbU/UoMzllLOFij7tEuJp1fCUq28VtpMP5hWv5SBoAVs/3pzKi5AgMBAAECggEAc3pNEsReNc1PDcbtzv6DswPaPnpxjqXZuCuXJ7e3aEHuZaWbWUF/bVjVya5EqQbwrTzf8l/t4SPXd6PbakCSc/JRtHUQ3iuM9bPOX0aiqR9YDfazpgeUSZV98ig3/h7tYMjVshEfW9AZ8j7mRy7SutEMjMWYJfoZatRGzPmi/DJcZbe8nhHLdz6I0B/zmAbaERv2WTiz8Tb4NdHNmjmdPNfMGLKXgOLInyDrH3aCxgHhuPPYIMnKvAOkkA+OVt2azSIcxlOxHQXPLm22snlI74mXiyYpo4z1hKJMmRvKOj6RmbFt5Kp2UMFPi2E59d4Xd0g+tBLrXBobZAxxn7IR8QKBgQDyxMypFjha56YC/aqQMhGfHFQALJJvJbzTJn2eDs1p5nVkoYI6CTZkxeS3vOQnYwzPBPrUHXA0zJqFLEtMyEqtVkQUzCIHeYewBhwAjVtAJ6G2tAF2hV5WdW04HfstqrTYC+oZNCWFH4PiymrdJ8zavBrHWd9o29MuTjcvDH8EKwKBgQDtUXMOaiafftaZOuHiCcsLXZKppsYyC3O0ocYukYpVaIMITmlHIxQusExWxRhz6vsIIlv8aNUraHbOrctDceSw5SfbkbhtwauI5W0S6GC51OCduhdlAYF4b8lE2IBN2ayFyE+uoIkNuvWssJEcWo27AmmDZb8BmZqFaEyu3A6gqwKBgFyABecrUz+34fZjxvh4S2SPu6XxVb5J57+ge96cj0IZkINOUrtgRTxydqpXq6siP4AlypjFurozd3DkprBT5LhVFU3DVff5I207drHzKmCweRqPTbtmJ8LTrVDjg5Ar6gojyAfgaadmka75J2yqvJBfeeiZYtmmYLnVDYu8vCzPAoGBAJFzNShliOyCSba6bw0h4W9C14vhKmIrwKu55wRNsVItbvndTQsLhegjp3Ya8KTDJT5UCLrH6bbkHMUJoaXhnT+KA4bAZh/m7mJF8zb+c6IRxeUF1CbU6GxPXzUx2Fleiy2nmqa1v6pJpx9DTHzrRyiSDuc4qfuqEBmp1i3ps5FnAoGAYII/2Y7zDoRCI8Ogzg4/yoRESoyzGb7mu/lxDj2JnaJkg+mFgDJZ3Yq3+OLwcEbeDEGUuGfnP+VS3FjTPO35AoXu42Z6ATHeinwOtul7HVgwf0hZQmglOrzHOBtHeSaR2wcs3syk3Kt7YnfPRtmOx2G1+NHismUYaki8oxBhWYQ="

    # the request data
    json_data_dict = {
        "mcht_order_no": "43671131975005794",
        "mcht_no": "test",
        "channel_no": 901001,
        "amount": "12300.5",
        "notify_url": "http://www.google.com",
        "req_time": "2675389933000",
        "code": "QRIS",
        "type": "qris",
        "name": "ata",
        "phone": "08123456789",
        "email": "ata@gmail.com"
    }
    json_data = json.dumps(json_data_dict)

    ppKey = format_key(PLATFORM_PUBLIC_KEY, "public")
    mpKey = format_key(MERCHANT_PRIVATE_KEY, "private")
    print(mpKey)

    context = public_key_encrypt(json_data, ppKey)
    sign = private_key_sign(context, mpKey)

    print("Encrypted data:", context)
    print("Signature:", sign)

    # Simulate request and return signature verification and decryption
    context = "n21qr8aMJfe4Pn78525mk/29vGyEkxLA9TbCGvOvVm0nmU5B8HzDmlQ/Zskc3IYk70oYt1+ALU7w7mAdlggGn3wqxfoRhy0HJaeCu3Q6dRYS4YMAhfoQL3BSkD2P8PUhKvuUvh6FfvBMoLx7FF0l4ceOFM1qp8MzglufmynxZ1R3JEJc/37vI4l2Jo7kjLJOgQ0VhrV6Ryu9TdqiFLOEkcj3cTUjVsOPghF7H5qDYe8ruyJ5nLhNWBdkI0+PTja4Uws6EyblnRhNiZNLoVbG+C44CxJuisLfaCSMef6uiLl4elECmwzWCpl/reYeg8vJ0KKGJJl8TOqDuw/uoGXly3HTidtpPFxcweppj6BtKeqYwIPlnAfetYIViPSKN7wQW3r40ogxsrF6c61GZmeAaZEb8+BIhmHK5iUg1diYvzFAhp3+M2EShDDI0gET7jzSalpwZH3sPrcG98aycjEljAILpuEJ91PjdURdzqFFNdWDKjjKbty3dQ5EJkP/uzTLjmZsxJaJAD/K8HpL6fKlSh+xHniXMJrdCI5Qg4upilvOjwaE+mdaJ0+jBgt35nLXwaIggCoa4YKHsYlh5+1xmPz1JpdCGh5Q0SRx3vk+K8gstlnT+6Q/vM8qLKjomALtTQoA/79vVmtyeZgxYx9I1nFaF/ya5pcQ1+aCalTwTh8="
    sign = "tBfvpSLEJpomhdLUJzLy2JxbbsvekiD+QLTYkTG8Oo3UJiayc33M6my5On8SMsYYr62F13dQ6nslpXSAPiWtwHgwVzlcBRFuvFuHqA/KIDZs2ZV51wqwf6MlXzfKXrpJC6WZXy+gEh96mzGglHmbNrd+Eo21ybIzLPz7igX0P2ASNgFKQEKLMVmnpQfNSKM4EgkEFcxK+fE8v3fdiixn4bsQvEG3xPcdU1uXMyauRDAFRCrAFSl7kZMUd7zT78HM6z+NcXwz18znrJuaeQILebGk/3M3TGof1LPBNeO2M9O1cz65y4Cpu8kP07X6KhXGZzw7JzgNGFfWdMJLO20f3g=="
    
    is_verified = public_key_verify(context, sign, ppKey)
    print("Verification result:", is_verified)

    context = private_key_decrypt(context, mpKey)
    print("Decrypted data:", context)
