package com.example;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

public class demo {
    // RSA public key encryption
    public static String publicKeyEncrypt(String data, String publicKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(publicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey pubKey = keyFactory.generatePublic(keySpec);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, pubKey);
        byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
        int inputLen = dataBytes.length;
        int maxBlockSize = 245; // for 2048-bit RSA keys, the maximum encryption length is 245 bytes
        int offSet = 0;
        byte[] cache;
        int i = 0;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            while (inputLen - offSet > 0) {
                int blockSize = Math.min(maxBlockSize, inputLen - offSet);
                cache = cipher.doFinal(dataBytes, offSet, blockSize);
                out.write(cache, 0, cache.length);
                offSet = ++i * maxBlockSize;
            }
            return Base64.getEncoder().encodeToString(out.toByteArray());
        }
    }

    // RSA private key decryption
    public static String privateKeyDecrypt(String data, String privateKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(privateKey);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey priKey = keyFactory.generatePrivate(keySpec);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, priKey);
        byte[] encryptedData = Base64.getDecoder().decode(data);
        int inputLen = encryptedData.length;
        int maxBlockSize = cipher.getOutputSize(Cipher.getMaxAllowedKeyLength("RSA"));
        int offSet = 0;
        byte[] cache;
        int i = 0;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            while (inputLen - offSet > 0) {
                int blockSize = Math.min(maxBlockSize, inputLen - offSet);
                cache = cipher.doFinal(encryptedData, offSet, blockSize);
                out.write(cache, 0, cache.length);
                offSet = ++i * maxBlockSize;
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    // RSA private key signature SHA256
    public static String privateKeySign(String data, String privateKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(privateKey);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey priKey = keyFactory.generatePrivate(keySpec);
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(priKey);
        signature.update(Base64.getDecoder().decode(data));
        return Base64.getEncoder().encodeToString(signature.sign());
    }

    // RSA public key signature verification SHA256
    public static boolean publicKeyVerify(String data, String sign, String publicKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(publicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey pubKey = keyFactory.generatePublic(keySpec);
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(pubKey);
        signature.update(Base64.getDecoder().decode(data));
        return signature.verify(Base64.getDecoder().decode(sign));
    }

    // main function
    public static void main(String[] args) {

        // Constant RSA Platform Public Key
        // Note that the key is only used for testing
        final String PLATFORM_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5r3MP/HV4aPh9vlsweB9w5ealEjPH35JtdbizypH1AK0fkm4zKqjSXzz2pJdxUJ7lOIvOLP8Ff0f4dOYtn+4PWRGLUSnG4YYvVI30NsGLDjC6iuaXpUMQ0hlctG/cY1RHfx7DzB5burwwqgxRg6L+pRM/xyVvUAy13SOjKLO4LZj3yExtYXzvX5b3aRtTgCeBTMFRE590Z7T3yVAkyAiS1DLvf1rtn+HbScV+Fu+l+XdbmoUB0XoRy5lnsPa5UxGs1cd3fjTp9V6vUwQVbWvSpnPO95Wa9NgeC+BtJTeFUgX6kFG981UTOX/DkaQcHzIBjYY8QV5Ka8FAl8Yh6fagwIDAQAB";

        // Constant RSA Merchant Private Key
        // Note that the key is only used for testing
        final String MERCHANT_PRIVATE_KEY = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDhDW7ZXm93bKeviJllOJFSq6ksCYA8l7Vw+4TCog11hRcb5JoSjQ2p4xh4nbj7u90yMdtkdM+uxTQ/6T79BAZeQEtTdNHFFLMuoENhc0VlQ6Plb/rcAFJ4O72s6oxtMDrzWWwnJpePkkySOzNLhsJpFYYehy2cr8Hq+Kx7ojYQbjlO8wdrCxkKsVn67Ad5Hf+1LHukBLdQZLQYH0jOEuyjU7lnJ8Stsblyyvjj/WpYBgLnEcKkzB31x05WiqE08nLeP8TydPYLK8NxUAzafvLWMNYgL7tqDp6FacbU/UoMzllLOFij7tEuJp1fCUq28VtpMP5hWv5SBoAVs/3pzKi5AgMBAAECggEAc3pNEsReNc1PDcbtzv6DswPaPnpxjqXZuCuXJ7e3aEHuZaWbWUF/bVjVya5EqQbwrTzf8l/t4SPXd6PbakCSc/JRtHUQ3iuM9bPOX0aiqR9YDfazpgeUSZV98ig3/h7tYMjVshEfW9AZ8j7mRy7SutEMjMWYJfoZatRGzPmi/DJcZbe8nhHLdz6I0B/zmAbaERv2WTiz8Tb4NdHNmjmdPNfMGLKXgOLInyDrH3aCxgHhuPPYIMnKvAOkkA+OVt2azSIcxlOxHQXPLm22snlI74mXiyYpo4z1hKJMmRvKOj6RmbFt5Kp2UMFPi2E59d4Xd0g+tBLrXBobZAxxn7IR8QKBgQDyxMypFjha56YC/aqQMhGfHFQALJJvJbzTJn2eDs1p5nVkoYI6CTZkxeS3vOQnYwzPBPrUHXA0zJqFLEtMyEqtVkQUzCIHeYewBhwAjVtAJ6G2tAF2hV5WdW04HfstqrTYC+oZNCWFH4PiymrdJ8zavBrHWd9o29MuTjcvDH8EKwKBgQDtUXMOaiafftaZOuHiCcsLXZKppsYyC3O0ocYukYpVaIMITmlHIxQusExWxRhz6vsIIlv8aNUraHbOrctDceSw5SfbkbhtwauI5W0S6GC51OCduhdlAYF4b8lE2IBN2ayFyE+uoIkNuvWssJEcWo27AmmDZb8BmZqFaEyu3A6gqwKBgFyABecrUz+34fZjxvh4S2SPu6XxVb5J57+ge96cj0IZkINOUrtgRTxydqpXq6siP4AlypjFurozd3DkprBT5LhVFU3DVff5I207drHzKmCweRqPTbtmJ8LTrVDjg5Ar6gojyAfgaadmka75J2yqvJBfeeiZYtmmYLnVDYu8vCzPAoGBAJFzNShliOyCSba6bw0h4W9C14vhKmIrwKu55wRNsVItbvndTQsLhegjp3Ya8KTDJT5UCLrH6bbkHMUJoaXhnT+KA4bAZh/m7mJF8zb+c6IRxeUF1CbU6GxPXzUx2Fleiy2nmqa1v6pJpx9DTHzrRyiSDuc4qfuqEBmp1i3ps5FnAoGAYII/2Y7zDoRCI8Ogzg4/yoRESoyzGb7mu/lxDj2JnaJkg+mFgDJZ3Yq3+OLwcEbeDEGUuGfnP+VS3FjTPO35AoXu42Z6ATHeinwOtul7HVgwf0hZQmglOrzHOBtHeSaR2wcs3syk3Kt7YnfPRtmOx2G1+NHismUYaki8oxBhWYQ=";

        // Request parameters TreeMap for sorting
        // Map data
        // Map<String, Object> map = new TreeMap<>();
        // map.put("name", "John");
        // map.put("age", 30);
        // map.put("address", "123 Main St");
        // map.put("email", "john@example.com");

        // Map to JSON string
        // ObjectMapper objectMapper = new ObjectMapper();
        // String json_data = objectMapper.writeValueAsString(map);

        // Test request string
        String json_data = "123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456";

        try {
            // Request encrypt and sign
            String context = publicKeyEncrypt(json_data, PLATFORM_PUBLIC_KEY);
            String sign = privateKeySign(context, MERCHANT_PRIVATE_KEY);
            System.out.println("context: " + context);
            System.out.println("sign: " + sign);

            // Simulate request and return signature verification and decryption
            context = "n21qr8aMJfe4Pn78525mk/29vGyEkxLA9TbCGvOvVm0nmU5B8HzDmlQ/Zskc3IYk70oYt1+ALU7w7mAdlggGn3wqxfoRhy0HJaeCu3Q6dRYS4YMAhfoQL3BSkD2P8PUhKvuUvh6FfvBMoLx7FF0l4ceOFM1qp8MzglufmynxZ1R3JEJc/37vI4l2Jo7kjLJOgQ0VhrV6Ryu9TdqiFLOEkcj3cTUjVsOPghF7H5qDYe8ruyJ5nLhNWBdkI0+PTja4Uws6EyblnRhNiZNLoVbG+C44CxJuisLfaCSMef6uiLl4elECmwzWCpl/reYeg8vJ0KKGJJl8TOqDuw/uoGXly3HTidtpPFxcweppj6BtKeqYwIPlnAfetYIViPSKN7wQW3r40ogxsrF6c61GZmeAaZEb8+BIhmHK5iUg1diYvzFAhp3+M2EShDDI0gET7jzSalpwZH3sPrcG98aycjEljAILpuEJ91PjdURdzqFFNdWDKjjKbty3dQ5EJkP/uzTLjmZsxJaJAD/K8HpL6fKlSh+xHniXMJrdCI5Qg4upilvOjwaE+mdaJ0+jBgt35nLXwaIggCoa4YKHsYlh5+1xmPz1JpdCGh5Q0SRx3vk+K8gstlnT+6Q/vM8qLKjomALtTQoA/79vVmtyeZgxYx9I1nFaF/ya5pcQ1+aCalTwTh8=";
            sign = "tBfvpSLEJpomhdLUJzLy2JxbbsvekiD+QLTYkTG8Oo3UJiayc33M6my5On8SMsYYr62F13dQ6nslpXSAPiWtwHgwVzlcBRFuvFuHqA/KIDZs2ZV51wqwf6MlXzfKXrpJC6WZXy+gEh96mzGglHmbNrd+Eo21ybIzLPz7igX0P2ASNgFKQEKLMVmnpQfNSKM4EgkEFcxK+fE8v3fdiixn4bsQvEG3xPcdU1uXMyauRDAFRCrAFSl7kZMUd7zT78HM6z+NcXwz18znrJuaeQILebGk/3M3TGof1LPBNeO2M9O1cz65y4Cpu8kP07X6KhXGZzw7JzgNGFfWdMJLO20f3g==";
            boolean verify = publicKeyVerify(context, sign, PLATFORM_PUBLIC_KEY);
            System.out.println("verify: " + verify);
            context = privateKeyDecrypt(context, MERCHANT_PRIVATE_KEY);
            System.out.println("context: " + context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}