
<?php
    // public key encryption
    function pubkeyEncrypt($source_data, $pu_key)
    {
        $data = "";
        $dataArray = str_split($source_data, 245);
        foreach ($dataArray as $value) {
            $encryptedTemp = "";
            openssl_public_encrypt($value, $encryptedTemp, $pu_key); // public key encryption
            $data .= $encryptedTemp;
        }
        return $data;
    }

    // private key decryption
    function pikeyDecrypt($eccryptData, $decryptKey)
    {
        $decrypted = "";
        $decodeStr = base64_decode($eccryptData);
        $enArray = str_split($decodeStr, 256);
        foreach ($enArray as $va) {
            $decryptedTemp = "";
            openssl_private_decrypt($va, $decryptedTemp, $decryptKey); // private key decryption
            $decrypted .= $decryptedTemp;
        }
        return $decrypted;
    }

    // private key signature
    function sign($private_key, $original_str)
    {
        $sign = "";
        openssl_sign($original_str, $sign, $private_key, OPENSSL_ALGO_SHA256);
        $sign = base64_encode($sign); // finally signature
        return $sign;
    }

    // public key verification
    function verify($sign, $public_key, $original_str)
    {
        $result = "";
        $sign = base64_decode($sign); // get sign
        $original_str = base64_decode($original_str); // get context
        $result = (bool)openssl_verify($original_str, $sign, $public_key, OPENSSL_ALGO_SHA256); // $result is true, pass
        return $result;
    }

    function format_secret_key($secret_key, $type)
    {
        // 64 English characters followed by a newline "\n", finilly followed by a newline "\n"
        $key = (wordwrap($secret_key, 64, "\n", true)) . "\n";
        // Add a pem header and tail
        if ($type == 'pub') {
            $pem_key = "-----BEGIN PUBLIC KEY-----\n" . $key . "-----END PUBLIC KEY-----\n";
        } else if ($type == 'pri') {
            $pem_key = "-----BEGIN RSA PRIVATE KEY-----\n" . $key . "-----END RSA PRIVATE KEY-----\n";
        } else {
            echo ('keys type invalid');
            exit();
        }
        return $pem_key;
    }

    // send data
    $data = array(
        'mcht_order_no' => '15991543671131975005794',
        'mcht_no' => 'mcht01',
        'channel_no' => 901001,
        'amount' => '123.45',
        'return_success_url' => 'http://www.google.com',
        'return_failure_url' => 'http://www.google.com',
        'notify_url' => 'http://www.google.com',
        'req_time' => '1675389933000',
        'code' => 'QRIS',
        'type' => 'qris',
        'name' => 'ata',
        'phone' => '+6282226158689',
        'email' => 'ata@gmail.com',
        // ......
    );


    // json encode
    $data = json_encode($data);

    echo $data;
    echo "\n";

    // merchant private key
    $mchtPrivateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDhDW7ZXm93bKeviJllOJFSq6ksCYA8l7Vw+4TCog11hRcb5JoSjQ2p4xh4nbj7u90yMdtkdM+uxTQ/6T79BAZeQEtTdNHFFLMuoENhc0VlQ6Plb/rcAFJ4O72s6oxtMDrzWWwnJpePkkySOzNLhsJpFYYehy2cr8Hq+Kx7ojYQbjlO8wdrCxkKsVn67Ad5Hf+1LHukBLdQZLQYH0jOEuyjU7lnJ8Stsblyyvjj/WpYBgLnEcKkzB31x05WiqE08nLeP8TydPYLK8NxUAzafvLWMNYgL7tqDp6FacbU/UoMzllLOFij7tEuJp1fCUq28VtpMP5hWv5SBoAVs/3pzKi5AgMBAAECggEAc3pNEsReNc1PDcbtzv6DswPaPnpxjqXZuCuXJ7e3aEHuZaWbWUF/bVjVya5EqQbwrTzf8l/t4SPXd6PbakCSc/JRtHUQ3iuM9bPOX0aiqR9YDfazpgeUSZV98ig3/h7tYMjVshEfW9AZ8j7mRy7SutEMjMWYJfoZatRGzPmi/DJcZbe8nhHLdz6I0B/zmAbaERv2WTiz8Tb4NdHNmjmdPNfMGLKXgOLInyDrH3aCxgHhuPPYIMnKvAOkkA+OVt2azSIcxlOxHQXPLm22snlI74mXiyYpo4z1hKJMmRvKOj6RmbFt5Kp2UMFPi2E59d4Xd0g+tBLrXBobZAxxn7IR8QKBgQDyxMypFjha56YC/aqQMhGfHFQALJJvJbzTJn2eDs1p5nVkoYI6CTZkxeS3vOQnYwzPBPrUHXA0zJqFLEtMyEqtVkQUzCIHeYewBhwAjVtAJ6G2tAF2hV5WdW04HfstqrTYC+oZNCWFH4PiymrdJ8zavBrHWd9o29MuTjcvDH8EKwKBgQDtUXMOaiafftaZOuHiCcsLXZKppsYyC3O0ocYukYpVaIMITmlHIxQusExWxRhz6vsIIlv8aNUraHbOrctDceSw5SfbkbhtwauI5W0S6GC51OCduhdlAYF4b8lE2IBN2ayFyE+uoIkNuvWssJEcWo27AmmDZb8BmZqFaEyu3A6gqwKBgFyABecrUz+34fZjxvh4S2SPu6XxVb5J57+ge96cj0IZkINOUrtgRTxydqpXq6siP4AlypjFurozd3DkprBT5LhVFU3DVff5I207drHzKmCweRqPTbtmJ8LTrVDjg5Ar6gojyAfgaadmka75J2yqvJBfeeiZYtmmYLnVDYu8vCzPAoGBAJFzNShliOyCSba6bw0h4W9C14vhKmIrwKu55wRNsVItbvndTQsLhegjp3Ya8KTDJT5UCLrH6bbkHMUJoaXhnT+KA4bAZh/m7mJF8zb+c6IRxeUF1CbU6GxPXzUx2Fleiy2nmqa1v6pJpx9DTHzrRyiSDuc4qfuqEBmp1i3ps5FnAoGAYII/2Y7zDoRCI8Ogzg4/yoRESoyzGb7mu/lxDj2JnaJkg+mFgDJZ3Yq3+OLwcEbeDEGUuGfnP+VS3FjTPO35AoXu42Z6ATHeinwOtul7HVgwf0hZQmglOrzHOBtHeSaR2wcs3syk3Kt7YnfPRtmOx2G1+NHismUYaki8oxBhWYQ=";
    // platform public key
    $platPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5r3MP/HV4aPh9vlsweB9w5ealEjPH35JtdbizypH1AK0fkm4zKqjSXzz2pJdxUJ7lOIvOLP8Ff0f4dOYtn+4PWRGLUSnG4YYvVI30NsGLDjC6iuaXpUMQ0hlctG/cY1RHfx7DzB5burwwqgxRg6L+pRM/xyVvUAy13SOjKLO4LZj3yExtYXzvX5b3aRtTgCeBTMFRE590Z7T3yVAkyAiS1DLvf1rtn+HbScV+Fu+l+XdbmoUB0XoRy5lnsPa5UxGs1cd3fjTp9V6vUwQVbWvSpnPO95Wa9NgeC+BtJTeFUgX6kFG981UTOX/DkaQcHzIBjYY8QV5Ka8FAl8Yh6fagwIDAQAB";

    // format key
    $mchtPrivateKey = format_secret_key($mchtPrivateKey, "pri");
    $platPublicKey = format_secret_key($platPublicKey, 'pub');

    echo $mchtPrivateKey;
    echo $platPublicKey;

    /********** request **********/
    // platform public key encryption
    $context = pubkeyEncrypt($data, $platPublicKey);
    echo "encryption result:";
    echo base64_encode($context);
    echo "\n";

    // merchant private key signature
    $sign = sign($mchtPrivateKey, $context);
    echo 'signature result:';
    echo $sign;
    echo "\n";

    echo 'request data: {"sign":"' . $sign . '","context":"' . base64_encode($context) . '"}';
    echo "\n";

    /********** callback **********/
    // get context and sign
    $context = "n21qr8aMJfe4Pn78525mk/29vGyEkxLA9TbCGvOvVm0nmU5B8HzDmlQ/Zskc3IYk70oYt1+ALU7w7mAdlggGn3wqxfoRhy0HJaeCu3Q6dRYS4YMAhfoQL3BSkD2P8PUhKvuUvh6FfvBMoLx7FF0l4ceOFM1qp8MzglufmynxZ1R3JEJc/37vI4l2Jo7kjLJOgQ0VhrV6Ryu9TdqiFLOEkcj3cTUjVsOPghF7H5qDYe8ruyJ5nLhNWBdkI0+PTja4Uws6EyblnRhNiZNLoVbG+C44CxJuisLfaCSMef6uiLl4elECmwzWCpl/reYeg8vJ0KKGJJl8TOqDuw/uoGXly3HTidtpPFxcweppj6BtKeqYwIPlnAfetYIViPSKN7wQW3r40ogxsrF6c61GZmeAaZEb8+BIhmHK5iUg1diYvzFAhp3+M2EShDDI0gET7jzSalpwZH3sPrcG98aycjEljAILpuEJ91PjdURdzqFFNdWDKjjKbty3dQ5EJkP/uzTLjmZsxJaJAD/K8HpL6fKlSh+xHniXMJrdCI5Qg4upilvOjwaE+mdaJ0+jBgt35nLXwaIggCoa4YKHsYlh5+1xmPz1JpdCGh5Q0SRx3vk+K8gstlnT+6Q/vM8qLKjomALtTQoA/79vVmtyeZgxYx9I1nFaF/ya5pcQ1+aCalTwTh8=";
    $sign = "tBfvpSLEJpomhdLUJzLy2JxbbsvekiD+QLTYkTG8Oo3UJiayc33M6my5On8SMsYYr62F13dQ6nslpXSAPiWtwHgwVzlcBRFuvFuHqA/KIDZs2ZV51wqwf6MlXzfKXrpJC6WZXy+gEh96mzGglHmbNrd+Eo21ybIzLPz7igX0P2ASNgFKQEKLMVmnpQfNSKM4EgkEFcxK+fE8v3fdiixn4bsQvEG3xPcdU1uXMyauRDAFRCrAFSl7kZMUd7zT78HM6z+NcXwz18znrJuaeQILebGk/3M3TGof1LPBNeO2M9O1cz65y4Cpu8kP07X6KhXGZzw7JzgNGFfWdMJLO20f3g==";
    // platform public key verification
    $v = verify($sign, $platPublicKey, $context);
    if ($v) {
        echo "verification success";
    } else {
        echo "verification fail";
    }
    echo "\n";

    // merchant private key decryption
    $m_context = pikeyDecrypt($context, $mchtPrivateKey);
    echo "decryption result:";
    echo $m_context;
    echo "\n";

    ?>